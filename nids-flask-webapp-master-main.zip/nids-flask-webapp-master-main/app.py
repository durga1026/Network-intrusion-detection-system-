import numpy as np
from flask import Flask, request, jsonify, render_template
import joblib
import logging
import os

# ── Logging ──────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s"
)
logger = logging.getLogger(__name__)

# ── App & Model ──────────────────────────────────────────
app = Flask(__name__)

MODEL_PATH = os.path.join(os.path.dirname(__file__), "model.pkl")
try:
    model = joblib.load(MODEL_PATH)
    logger.info("Model loaded successfully from %s", MODEL_PATH)
except Exception as e:
    logger.error("Failed to load model: %s", e)
    raise


# ── Helpers ──────────────────────────────────────────────
ATTACK_LABELS = {0: "Normal", 1: "DOS", 2: "PROBE", 3: "R2L", 4: "U2R"}

# Top-15 feature names expected by the model (in order)
FEATURE_ORDER = [
    "attack_neptune", "attack_normal", "attack_satan",
    "count",
    "dst_host_diff_srv_rate", "dst_host_same_src_port_rate",
    "dst_host_same_srv_rate", "dst_host_srv_count",
    "flag_S0", "flag_SF",
    "last_flag", "logged_in",
    "same_srv_rate", "serror_rate", "service_http",
]

def encode_attack(val: int) -> list:
    """One-hot encode attack type into [neptune, normal, satan]."""
    mapping = {
        0: [0, 0, 0],   # Other
        1: [1, 0, 0],   # neptune
        2: [0, 1, 0],   # normal
        3: [0, 0, 1],   # satan
    }
    return mapping.get(int(val), [0, 0, 0])

def encode_flag(val: int) -> list:
    """One-hot encode flag into [flag_S0, flag_SF]."""
    mapping = {
        0: [0, 0],   # Other
        1: [1, 0],   # S0
        2: [0, 1],   # SF
    }
    return mapping.get(int(val), [0, 0])

def build_feature_vector(raw: list) -> np.ndarray:
    """
    raw = [attack, count, dst_host_diff_srv_rate, dst_host_same_src_port_rate,
           dst_host_same_srv_rate, dst_host_srv_count, flag,
           last_flag, logged_in, same_srv_rate, serror_rate, service_http]
    Returns 15-element numpy array matching FEATURE_ORDER.
    """
    attack_encoded  = encode_attack(raw[0])       # [neptune, normal, satan]
    numeric_mid     = [float(x) for x in raw[1:6]] # count, d_h_d, d_h_sp, d_h_s, d_h_sc  (wait – raw[1..5])
    flag_encoded    = encode_flag(raw[6])           # [S0, SF]
    numeric_tail    = [float(x) for x in raw[7:]]  # last_flag, logged_in, same_srv_rate, serror_rate, service_http

    vector = attack_encoded + numeric_mid + flag_encoded + numeric_tail
    if len(vector) != 15:
        raise ValueError(f"Feature vector length {len(vector)} != 15")
    return np.array(vector, dtype=float)

def label_from_prediction(pred) -> str:
    return ATTACK_LABELS.get(int(pred[0]), "Unknown")


# ── Routes ───────────────────────────────────────────────
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        raw = [float(x) for x in request.form.values()]
        if len(raw) != 12:
            raise ValueError(f"Expected 12 form values, got {len(raw)}")

        features = build_feature_vector(raw)
        prediction = model.predict([features])
        output = label_from_prediction(prediction)
        logger.info("Prediction: %s  |  features: %s", output, features.tolist())
        return render_template("prediction.html", output=output, features=dict(zip(FEATURE_ORDER, features)))

    except ValueError as e:
        logger.warning("Bad input: %s", e)
        return render_template("prediction.html", output=None, error=str(e)), 400
    except Exception as e:
        logger.error("Prediction error: %s", e)
        return render_template("prediction.html", output=None, error="Internal server error"), 500


@app.route("/results", methods=["POST"])
def results():
    """JSON API endpoint.
    Accepts either:
      - {"features": [v1, v2, ..., v15]}   (pre-encoded, 15 values)
      - {"raw": [v1, ..., v12]}             (raw form values, 12 values)
    """
    try:
        data = request.get_json(force=True)
        if data is None:
            return jsonify({"error": "Invalid JSON"}), 400

        if "features" in data:
            vec = np.array(data["features"], dtype=float)
            if vec.shape[0] != 15:
                return jsonify({"error": "features must have 15 values"}), 400
        elif "raw" in data:
            vec = build_feature_vector([float(x) for x in data["raw"]])
        else:
            # Legacy: plain dict of feature_name -> value
            vec = np.array(list(data.values()), dtype=float)

        prediction = model.predict([vec])
        output = label_from_prediction(prediction)
        logger.info("API Prediction: %s", output)
        return jsonify({"prediction": output, "class_id": int(prediction[0])})

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error("API error: %s", e)
        return jsonify({"error": "Internal server error"}), 500


@app.route("/health")
def health():
    """Health check endpoint for container orchestration."""
    return jsonify({"status": "ok", "model_loaded": model is not None})


# ── Entry point ───────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_ENV") == "development"
    app.run(host="0.0.0.0", port=port, debug=debug)