# Network Intrusion Detection System (NIDS)

A machine-learning–powered web application that classifies network traffic into five categories — **Normal**, **DoS**, **Probe**, **R2L**, and **U2R** — using a Logistic Regression model trained on the NSL-KDD benchmark dataset.

---

## 🚀 Quick Start

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd nids-webapp

# 2. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app (development)
FLASK_ENV=development python app.py

# Open http://localhost:5000
```

---

## 🐳 Docker

```bash
# Build
docker build -t nids-app .

# Run
docker run -p 5000:5000 nids-app

# Open http://localhost:5000
```

---

## 📁 Project Structure

```
nids-webapp/
├── app.py                  # Flask application
├── model.pkl               # Trained Logistic Regression model
├── requirements.txt        # Python dependencies
├── Dockerfile              # Container build instructions
├── Procfile                # Gunicorn entry point (Heroku / PaaS)
├── templates/
│   ├── index.html          # Prediction input form
│   └── prediction.html     # Result display page
└── static/
    └── style.css           # Application styles
```

---

## 🌐 API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| `GET`  | `/`   | Prediction form (web UI) |
| `POST` | `/predict` | Form submission → HTML result |
| `POST` | `/results`  | JSON API → JSON prediction |
| `GET`  | `/health`   | Health check |

### JSON API Example

```bash
# Using raw 12-value input
curl -X POST http://localhost:5000/results \
  -H "Content-Type: application/json" \
  -d '{"raw": [1, 229, 0.06, 0.00, 0.04, 10, 0, 21, 0, 0.04, 0.00, 0]}'

# Response
{"prediction": "Normal", "class_id": 0}

# Using pre-encoded 15 features
curl -X POST http://localhost:5000/results \
  -H "Content-Type: application/json" \
  -d '{"features": [1,0,0, 229, 0.06, 0.00, 0.04, 10, 0,0, 21, 0, 0.04, 0.00, 0]}'
```

---

## 📊 Input Parameters (Form)

| # | Field | Description | Range |
|---|-------|-------------|-------|
| 1 | **Attack Type** | Known attack signature | 0=Other, 1=neptune, 2=normal, 3=satan |
| 2 | **Count** | Connections to same destination in 2 sec | 0–511 |
| 3 | **Dst Host Diff Srv Rate** | % to different services | 0.00–1.00 |
| 4 | **Dst Host Same Src Port Rate** | % from same source port | 0.00–1.00 |
| 5 | **Dst Host Same Srv Rate** | % to same service | 0.00–1.00 |
| 6 | **Dst Host Srv Count** | Connections with same destination port | 0–255 |
| 7 | **Flag** | Connection status | 0=Other, 1=S0, 2=SF |
| 8 | **Last Flag** | Last flag numeric code | integer |
| 9 | **Logged In** | Successful login | 0 or 1 |
| 10 | **Same Srv Rate** | % to same service (2s window) | 0.00–1.00 |
| 11 | **Serror Rate** | % connections with SYN errors | 0.00–1.00 |
| 12 | **Service HTTP** | Destination is HTTP? | 0 or 1 |

---

## 🎯 Attack Classes

| Class | Label | Description | Examples |
|-------|-------|-------------|---------|
| 0 | **Normal** | Legitimate traffic | — |
| 1 | **DoS** | Depletes victim resources | neptune, smurf, pod, teardrop |
| 2 | **Probe** | Network reconnaissance | satan, ipsweep, nmap, portsweep |
| 3 | **R2L** | Unauthorized remote access | guess_password, ftp_write, imap |
| 4 | **U2R** | Privilege escalation | buffer_overflow, rootkit, perl |

---

## 🗂️ Dataset

**NSL-KDD** — an improved version of the KDDCUP'99 dataset.

- Training: 125,973 records
- Testing: 22,544 records
- Source: http://www.unb.ca/cic/datasets/nsl.html

---

## 🤖 Model Details

- **Algorithm**: Logistic Regression (multinomial, lbfgs solver)
- **Feature selection**: SelectKBest — F-Classif (k=15)
- **Test accuracy**: ~98%
- **Serialization**: Joblib

**Top 15 features**: `attack_neptune`, `attack_normal`, `attack_satan`, `count`, `dst_host_diff_srv_rate`, `dst_host_same_src_port_rate`, `dst_host_same_srv_rate`, `dst_host_srv_count`, `flag_S0`, `flag_SF`, `last_flag`, `logged_in`, `same_srv_rate`, `serror_rate`, `service_http`

---

## ☁️ Deploy to Heroku

```bash
heroku create your-nids-app
git push heroku main
heroku open
```

---

## 📦 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| Flask | 2.3.3 | Web framework |
| scikit-learn | 1.3.2 | ML model |
| joblib | 1.3.2 | Model serialization |
| numpy | 1.26.4 | Numerical arrays |
| gunicorn | 21.2.0 | Production WSGI server |

---

## 📄 License

MIT License — see `LICENSE` for details.